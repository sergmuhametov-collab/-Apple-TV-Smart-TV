package com.gathin.tvhome;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/**
 * An Apple-style on/off switch for the day (on) and night (off) backdrop: a rounded track and a white knob that
 * slides across it, with a moon on the knob at night and a sun by day.
 */
public class DayNightSwitch extends View {
    private static final int TRACK_NIGHT = 0x40FFFFFF;
    private static final int TRACK_DAY = 0xFFFFC857;
    private static final int INK = 0xFF30404A;

    private final float density;
    private final boolean animate;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path moon = new Path();
    private final Path bite = new Path();
    private boolean day;
    /** 0 is night, 1 is day. */
    private float progress;
    private ValueAnimator animator;

    public DayNightSwitch(Context context, boolean animate) {
        super(context);
        this.density = getResources().getDisplayMetrics().density;
        this.animate = animate;
        setFocusable(true);
        setClickable(true);
    }

    boolean isDay() {
        return day;
    }

    void setDay(boolean day, boolean animated) {
        this.day = day;
        if (animator != null) animator.cancel();
        float target = day ? 1f : 0f;
        if (!animated || !animate) {
            progress = target;
            invalidate();
            return;
        }
        animator = ValueAnimator.ofFloat(progress, target);
        animator.setDuration(200);
        animator.addUpdateListener(a -> {
            progress = (Float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (animator != null) animator.cancel();
        super.onDetachedFromWindow();
    }

    private static int blend(int from, int to, float t) {
        int a = Math.round(Color.alpha(from) + (Color.alpha(to) - Color.alpha(from)) * t);
        int r = Math.round(Color.red(from) + (Color.red(to) - Color.red(from)) * t);
        int g = Math.round(Color.green(from) + (Color.green(to) - Color.green(from)) * t);
        int b = Math.round(Color.blue(from) + (Color.blue(to) - Color.blue(from)) * t);
        return Color.argb(a, r, g, b);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float d = density;
        float w = 52 * d;
        float h = 30 * d;
        float left = (getWidth() - w) / 2f;
        float top = (getHeight() - h) / 2f;
        rect.set(left, top, left + w, top + h);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(blend(TRACK_NIGHT, TRACK_DAY, progress));
        canvas.drawRoundRect(rect, h / 2f, h / 2f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, d));
        paint.setColor(0x33FFFFFF);
        canvas.drawRoundRect(rect, h / 2f, h / 2f, paint);

        float knob = 26 * d;
        float pad = 2 * d;
        float cx = left + pad + knob / 2f + (w - 2 * pad - knob) * progress;
        float cy = top + h / 2f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x30000000);
        canvas.drawCircle(cx, cy + d, knob / 2f, paint);
        paint.setColor(Color.WHITE);
        canvas.drawCircle(cx, cy, knob / 2f, paint);

        // The moon fades out as the knob moves to day.
        int moonAlpha = Math.round(255 * (1f - progress));
        if (moonAlpha > 0) {
            moon.reset();
            moon.addCircle(cx, cy, 6 * d, Path.Direction.CW);
            bite.reset();
            bite.addCircle(cx + 3.5f * d, cy - 2.5f * d, 5 * d, Path.Direction.CW);
            moon.op(bite, Path.Op.DIFFERENCE);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(INK);
            paint.setAlpha(moonAlpha);
            canvas.drawPath(moon, paint);
        }
        // The sun fades in.
        int sunAlpha = Math.round(255 * progress);
        if (sunAlpha > 0) {
            paint.setColor(INK);
            paint.setAlpha(sunAlpha);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(cx, cy, 4 * d, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.5f * d);
            paint.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < 8; i++) {
                double angle = Math.PI / 4 * i;
                float cos = (float) Math.cos(angle);
                float sin = (float) Math.sin(angle);
                canvas.drawLine(cx + cos * 6.5f * d, cy + sin * 6.5f * d,
                        cx + cos * 9f * d, cy + sin * 9f * d, paint);
            }
            paint.setStrokeCap(Paint.Cap.BUTT);
        }
    }
}
