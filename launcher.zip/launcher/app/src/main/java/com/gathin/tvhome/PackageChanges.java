package com.gathin.tvhome;

import android.content.Context;
import android.content.pm.ChangedPackages;
import android.os.Build;

import androidx.annotation.RequiresApi;

/**
 * PackageManager.getChangedPackages exists from Android 8.0 (API 26). On older TVs the launcher rebuilds
 * its tiles from the package broadcasts alone, so these helpers report "nothing changed".
 */
final class PackageChanges {
    private PackageChanges() {
    }

    /** True when apps changed since {@code sequence}; always false below Android 8.0. */
    static boolean since(Context context, int sequence) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false;
        return Api26.since(context, sequence);
    }

    /** The current change counter, or {@code since} unchanged below Android 8.0. */
    static int sequence(Context context, int since) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return since;
        return Api26.sequence(context, since);
    }

    /** Kept in its own class so the old system never loads a reference to ChangedPackages. */
    @RequiresApi(Build.VERSION_CODES.O)
    private static final class Api26 {
        static boolean since(Context context, int sequence) {
            ChangedPackages changed = context.getPackageManager().getChangedPackages(sequence);
            return changed != null && !changed.getPackageNames().isEmpty();
        }

        static int sequence(Context context, int since) {
            ChangedPackages changed = context.getPackageManager().getChangedPackages(since);
            return changed != null ? changed.getSequenceNumber() : since;
        }
    }
}
